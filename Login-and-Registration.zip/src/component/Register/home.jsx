import React from "react";
import "./style.scss";
import { Redirect } from "react-router-dom";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import LockIcon from "@material-ui/icons/Lock";
/* import Snackbar from "@material-ui/core/Snackbar";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";
 */
import Dialog from "@material-ui/core/Dialog";

import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Slide from "@material-ui/core/Slide";
import { Button } from "@material-ui/core";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});
export class Home extends React.Component {
  constructor(props) {
    super(props);

    const token = localStorage.getItem("token");
    let loggedIn = true;
    if (token === null) {
      loggedIn = false;
    }
    this.state = {
      loggedIn,
      data: [],
      msg: "",
      setOpen: false,
    };

    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);

    this.remder = this.render.bind(this);
    this.user = JSON.parse(localStorage.getItem("register_details"));
    this.user.map((data) => (this.username = data.username));
    this.user.map((data) => (this.gmail = data.email));
    this.data = this.user;
  }
  handleClick(event) {
    localStorage.removeItem("token");
    this.setState({
      loggedIn: false,
    });
  }
  handleClickOpen = () => {
    this.setState({
      setOpen: true,
    });
  };
  handleClose = (event, reason) => {
    this.setState({
      setOpen: false,
    });
  };

  render() {
    const Data = this.data;

    if (this.state.loggedIn === false) {
      this.msg = "Thank You ! login again to enter Home page";
      this.setState({
        msg: this.msg,
      });
      return <Redirect to="/login" />;
    }

    return (
      <div className="full">
        <div className="base-container">
          <div className="tag">
            <LockIcon className="tag1" onClick={this.handleClickOpen} />{" "}
            {this.username}
          </div>
          <div className="header">Home Page</div>

          <Card className="root">
            <CardContent>
              <Typography>
                Welcome <b>{this.username}</b>
              </Typography>
              <Typography variant="body2" color="textSecondary" component="p">
                “The most wasted of days is one without laughter.”
                <br></br>– E.E. Cummings.
              </Typography>
            </CardContent>
          </Card>

          <div className="data">
            <p>Users</p>
            {Data.map((res) => (
              <div key={res.username}>
                <Card>
                  <CardContent>
                    <Typography>
                      <b>{res.username}</b>
                    </Typography>
                    <Typography>
                      <b>{res.email}</b>
                    </Typography>
                  </CardContent>
                </Card>
                <br></br>
              </div>
            ))}
          </div>

          <div className="footer">
            <button
              type="button"
              className="btn"
              onClick={this.handleClickOpen}
            >
              LogOut
            </button>
            <Dialog
              open={this.state.setOpen}
              TransitionComponent={Transition}
              keepMounted
              onClose={this.handleClose}
              aria-labelledby="alert-dialog-slide-title"
              aria-describedby="alert-dialog-slide-description"
            >
              <DialogTitle id="alert-dialog-slide-title">LogOut</DialogTitle>
              <DialogContent>
                <DialogContentText id="alert-dialog-slide-description">
                  Do you really want to LogOut??
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={this.handleClose} color="primary">
                  Disagree
                </Button>
                <Button
                  onClick={(event) => this.handleClick(event)}
                  color="primary"
                >
                  Agree
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        </div>
      </div>
    );
  }
}
export default Home;
