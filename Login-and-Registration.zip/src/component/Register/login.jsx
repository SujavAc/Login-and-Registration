import React from "react";
import "./style.scss";
import { Redirect } from "react-router-dom";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Snackbar from "@material-ui/core/Snackbar";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";

export class Login extends React.Component {
  constructor(props) {
    super(props);
    let loggedIn = false;  //consider the loggedIn value false in the begining
    let token = localStorage.getItem("token");  //get the token value store in the local storage
    this.state = {      //initial variables
      email: "",
      password: "",
      login: [],
      data: "",
      loggedIn,
      token,
      check: [],
      msg: "",
      setOpen: false,
    };
    this.handleClick = this.handleClick.bind(this);   //bind the value in function handleClick
    this.render = this.render.bind(this);
    this.login = JSON.parse(localStorage.getItem("register_details"));
  }
  handleEmailChange = (e) => {
    this.setState({
      email: e.target.value,
    });
  };
  handlePasswordChange = (e) => {
    this.setState({
      password: e.target.value,
    });
  };

  handleClick = (event) => {
    this.setState({
      setOpen: true,
    });
    this.login.map((data) => (this.gmail = data.email));
    this.login.map((data) => (this.pass = data.password));
    console.log(this.gmail);
    console.log(this.pass);

    if (this.state.email === this.gmail && this.state.password === this.pass) {
      this.msg = "verified user";
      this.setState({
        msg: this.msg,
      });
      localStorage.setItem("token", "dshfgsdfyusgf43657843hb43ghgfhd");
      this.setState({
        loggedIn: true,
      });
    } else {
      this.msg = "Enter valid inputs";
      this.setState({
        msg: this.msg,
      });
    }
  };
  handleClose = (event, reason) => {
    this.setState({
      setOpen: false,
    });
  };

  render() {
    if (this.state.loggedIn === true) {
      return <Redirect to="/home" />;
    } else if (this.state.token) {
      this.msg = "Already loggedin";
      this.setState({
        msg: this.msg,
      });
      return <Redirect to="/home" />;
    }

    return (
      <div className="full">
        <div className="base-container" ref={this.props.containerRef}>
          <div className="header">Login</div>
          <div className="content">
            <div className="form">
              <div className="form-group">
                <TextField
                  label="Email"
                  type="email"
                  name="email"
                  onChange={this.handleEmailChange}
                  required
                />
              </div>

              <div className="form-group">
                <TextField
                  label="Password"
                  type="password"
                  name="password"
                  onChange={this.handlePasswordChange}
                  required
                />
              </div>
            </div>
          </div>
          <div className="footer">
            <Button
              variant="contained"
              type="button"
              className="btn"
              onClick={(event) => this.handleClick(event)}
            >
              Login
            </Button>
            <Snackbar
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "center",
              }}
              open={this.state.setOpen}
              autoHideDuration={6000}
              onClose={this.handleClose}
              message={this.state.msg}
              action={
                <React.Fragment>
                  <IconButton
                    size="small"
                    aria-label="close"
                    color="inherit"
                    onClick={this.handleClose}
                  >
                    <CloseIcon fontSize="small" />
                  </IconButton>
                </React.Fragment>
              }
            />
          </div>
        </div>
      </div>
    );
  }
}
export default Login;
